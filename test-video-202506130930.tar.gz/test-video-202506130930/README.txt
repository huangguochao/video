#功能: 为图片添加字幕后，生成视频。
1) Linux OS

2) Install
#pip install flask opencv-python pillow numpy

3) Directory
project/
├── app.py
├── templates/
│   ├── index.html
│   └── result.html
├── uploads/
└── outputs/

4) python app.py

5) http://localhost:5000
